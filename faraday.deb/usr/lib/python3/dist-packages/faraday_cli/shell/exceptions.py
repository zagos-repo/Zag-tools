class InvalidJson(Exception):
    pass


class InvalidJsonSchema(Exception):
    pass
