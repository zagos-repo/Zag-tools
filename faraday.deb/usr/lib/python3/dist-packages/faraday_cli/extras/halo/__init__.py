# -*- coding: utf-8 -*-
__author__ = "Manraj Singh"
__email__ = "manrajsinghgrover@gmail.com"

import logging


logging.getLogger(__name__).addHandler(logging.NullHandler())
